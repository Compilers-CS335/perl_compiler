$a = 3;
$a == 4 ? $b=1 : $b=2;
print $b;