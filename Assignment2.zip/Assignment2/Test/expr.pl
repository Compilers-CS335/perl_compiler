#!/usr/bin/perl

# print "Hello\n";
$a = 2;
$a = $b + 1;
print("\$a = $a and \$b = $b \n");
print("\$a = $a1 and \$b = $b1 \n");
