#!/usr/bin/perl

# print "Hello\n";
$a , $b = 2;
($a1, $b1) = (90, 100);
print("\$a = $a and \$b = $b \n");
print("\$a = $a1 and \$b = $b1 \n");